﻿using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using SB_DomainLayer.Models;
using SB_DomainLayer.RequestModel;
using SB_RepositoryLayer.SB_DbContext;
using SB_ServiceLayer.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SB_ServiceLayer.Service
{
    public class ProductManager: IProductManager
    {
        private readonly ApplicationDbContext _dBContext;
        private readonly IConfiguration _configuration;
        private readonly SignInManager<ApplicationUser> _signInManager;
        private readonly RoleManager<ApplicationRole> _roleManager;
        private readonly UserManager<ApplicationUser> _userManager;
        public ProductManager(ApplicationDbContext dBContext, RoleManager<ApplicationRole> roleManager, SignInManager<ApplicationUser> signInManager, IConfiguration configuration, UserManager<ApplicationUser> userManager)
        {
            _dBContext = dBContext;
            _roleManager = roleManager;
            _configuration = configuration;
            _userManager = userManager;
            _configuration = configuration;
            _signInManager = signInManager;
        }

        /// <summary>
        /// Method for admin to add a product detail.
        /// </summary>
        /// <param name="product"></param>
        /// <param name="addedBy"></param>
        /// <returns></returns>
        public async Task<bool> AddProductWithDetails(AddProduct product, string addedBy)
        {
            bool status = false;
            ProductDetail productDetail = new ProductDetail();
            productDetail.ProductName = product.ProductName;
            productDetail.ProductCategory = product.ProductCategory;
            productDetail.ProductDescription = product.ProductDescription;
            productDetail.IsValid = true;
            productDetail.CreatedBy = addedBy;
            productDetail.CreatedDateTime = DateTime.UtcNow;
            productDetail.ModifiedBy = addedBy;
            productDetail.ModifiedDateTime = DateTime.UtcNow;
                _dBContext.tblSB_ProductDetail.Add(productDetail);
            var result =   await _dBContext.SaveChangesAsync();
            if (result == 1)
            {
                status= true;
            }
            return status;
        }

        /// <summary>
        /// Method for admin to update a product detail
        /// </summary>
        /// <param name="product"></param>
        /// <param name="updatedBy"></param>
        /// <returns></returns>
        public async Task<bool> UpdateProductDetails(ProductDetail product, string updatedBy)
        {
            bool status = false;
            var orgProduct = _dBContext.tblSB_ProductDetail.Where(a => a.ProductID == product.ProductID).FirstOrDefault();
            orgProduct.ModifiedBy = updatedBy;
            orgProduct.ModifiedDateTime = DateTime.UtcNow;
            orgProduct.ProductDescription = product.ProductDescription;
            orgProduct.ProductName = product.ProductName;
            orgProduct.ProductCategory = product.ProductCategory;
            _dBContext.tblSB_ProductDetail.Update(orgProduct);
            var result = await _dBContext.SaveChangesAsync();
            if (result == 1)
            {
                status = true;
            }
            return status;
        }

        /// <summary>
        /// Delete product
        /// </summary>
        /// <param name="productId"></param>
        /// <param name="updatedBy"></param>
        /// <returns></returns>
        public async Task<bool> DeleteProductByProductId(int productId, string updatedBy)
        {
            bool status = false;
            var orgProduct = _dBContext.tblSB_ProductDetail.Where(a => a.ProductID == productId).FirstOrDefault();
            orgProduct.ModifiedBy = updatedBy;
            orgProduct.ModifiedDateTime = DateTime.UtcNow;
            orgProduct.IsValid = false;
            _dBContext.tblSB_ProductDetail.Update(orgProduct);
            var result = await _dBContext.SaveChangesAsync();
            if (result == 1)
            {
                status = true;
            }
            return status;
        }

        /// <summary>
        /// Method for seller to add product
        /// </summary>
        /// <param name="product"></param>
        /// <param name="addedBy"></param>
        /// <returns></returns>
        public async Task<bool> ListProductForSale(ListProduct product, string addedBy)
        {
            bool status = false;
            var user = await _userManager.FindByNameAsync(addedBy);
            ProductListingDetail listingDetail = new ProductListingDetail();
            listingDetail.SellerID = user.Id;
            listingDetail.LastModifiedDateTime = DateTime.UtcNow;
            listingDetail.ProductID = product.ProductId;
            listingDetail.Quantity = (int)product.Quantity;
            listingDetail.UnitSellingPrice = (decimal)product.UnitSellingPrice;
            _dBContext.tblSB_ProductListingDetail.Add(listingDetail);
            var result = await _dBContext.SaveChangesAsync();
            if (result == 1)
            {
                status = true;
            }
            return status;
        }

        /// <summary>
        /// Method for seller to update price of a listed product 
        /// </summary>
        /// <param name="product"></param>
        /// <param name="updatedBy"></param>
        /// <returns></returns>
        public async Task<bool> UpdatePriceOfListedProduct(ListProduct product)
        {
            bool status = false;
            var listedProduct = _dBContext.tblSB_ProductListingDetail.Where(a=>a.ID== product.ListedID).FirstOrDefault();
            listedProduct.UnitSellingPrice = (decimal)product.UnitSellingPrice;
            listedProduct.LastModifiedDateTime = DateTime.Now;
            _dBContext.tblSB_ProductListingDetail.Update(listedProduct);
            var result = await _dBContext.SaveChangesAsync();
            if (result == 1)
            {
                status = true;
            }
            return status;
        }

        /// <summary>
        /// Method for seller to add or remove quantity of listed product
        /// </summary>
        /// <param name="product"></param>
        /// <param name="updatedBy"></param>
        /// <returns></returns>
        public async Task<bool> UpdateQuantityOfListedProduct(ListProduct product)
        {
            bool status = false;
            var listedProduct = _dBContext.tblSB_ProductListingDetail.Where(a => a.ID == product.ListedID).FirstOrDefault();
            listedProduct.Quantity = (int)product.Quantity;
            listedProduct.LastModifiedDateTime = DateTime.Now;
            _dBContext.tblSB_ProductListingDetail.Update(listedProduct);
            var result = await _dBContext.SaveChangesAsync();
            if (result == 1)
            {
                status = true;
            }
            return status;
        }

        /// <summary>
        /// Method for Buyer to buy a product
        /// </summary>
        /// <param name="product"></param>
        /// <param name="purchasedBy"></param>
        /// <returns></returns>
        public async Task<bool> BuyListedProduct(BuyProduct product, string purchasedBy)
        {
            bool status = false;
            var user = await _userManager.FindByNameAsync(purchasedBy);
            var listedProduct = _dBContext.tblSB_ProductListingDetail.Where(a => a.ID == product.ListedID).FirstOrDefault();
            listedProduct.Quantity = listedProduct.Quantity-product.Quantity;
            _dBContext.tblSB_ProductListingDetail.Update(listedProduct);
             await _dBContext.SaveChangesAsync();

            //////-----There wil be some code here to charge user for this purchase-------/////

            ProductSellingDetail productSellingDetail = new ProductSellingDetail();
            productSellingDetail.ListedId = product.ListedID;
            productSellingDetail.PurchasedDateTime = DateTime.UtcNow;
            productSellingDetail.Quantity = product.Quantity;
            productSellingDetail.PurchasePrice = listedProduct.UnitSellingPrice;
            productSellingDetail.PurchasedBy = user.Id;
            _dBContext.tblSB_ProductSellingDetail.Add(productSellingDetail);
            var result = await _dBContext.SaveChangesAsync();
            if (result == 1)
            {
                status = true;
            }
            /////------There will be some code here to get the user's shipping detail send that to seller so that he can send the product to buyer-----/////

            return status;
        }

        /// <summary>
        /// Method to get the list of all the products
        /// </summary>
        /// <returns></returns>
        public async Task<List<ProductDetail>> GetAllProductList()
        {

            var productList = await _dBContext.tblSB_ProductDetail.ToListAsync();
           
            return productList;
        }

        /// <summary>
        /// Method to get product by category
        /// </summary>
        /// <param name="category"></param>
        /// <returns></returns>
        public async Task<List<ProductDetail>> GetProductListForCategory(string category)
        {

            var productList = await _dBContext.tblSB_ProductDetail.Where(p=>p.ProductCategory==category).ToListAsync();

            return productList;
        }

        /// <summary>
        /// Method to get all the listed products by product id
        /// </summary>
        /// <param name="productId"></param>
        /// <returns></returns>
        public async Task<List<ProductListingDetail>> GetAllListedProductByProductId(int productId)
        {

            var productList = await _dBContext.tblSB_ProductListingDetail.Where(p => p.ProductID == productId).ToListAsync();

            return productList;
        }

    }
}
