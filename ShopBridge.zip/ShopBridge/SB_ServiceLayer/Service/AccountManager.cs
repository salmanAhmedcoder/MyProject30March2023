﻿using Microsoft.AspNetCore.Identity;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using SB_DomainLayer.DTO;
using SB_DomainLayer.Models;
using SB_DomainLayer.RequestModel;
using SB_RepositoryLayer.SB_DbContext;
using SB_ServiceLayer.Interface;
using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;

namespace SB_ServiceLayer.Service
{
   public class AccountManager:IAccountManager
    {
        private readonly ApplicationDbContext _dBContext;
        private readonly IConfiguration _configuration;
        private readonly SignInManager<ApplicationUser> _signInManager;
        private readonly RoleManager<ApplicationRole> _roleManager;
        private readonly UserManager<ApplicationUser> _userManager;
        public AccountManager(ApplicationDbContext dBContext,RoleManager<ApplicationRole> roleManager, SignInManager<ApplicationUser> signInManager, IConfiguration configuration, UserManager<ApplicationUser> userManager)
        {
            _dBContext = dBContext;
            _roleManager = roleManager;
            _userManager = userManager;
            _configuration = configuration;
            _signInManager = signInManager;
        }
        public async Task<ApplicationUserDTO> UserRegisteration(UserRegistration userRegistration, string createdBy)
        {
            ApplicationUserDTO newUser = new ApplicationUserDTO();
            var user = new ApplicationUser
            {
                UserName = userRegistration.UserName,
                Email = userRegistration.EmailId,
                CreatedBy = createdBy,
                EmailConfirmed =true,
                LockoutEnabled = false,
                ModifiedBy = createdBy,
                IsActive = true,
                IsDeleted = false,
                CreatedDate = DateTime.UtcNow,
                ModifiedDate = DateTime.UtcNow,
            };

            var result = await _userManager.CreateAsync(user, userRegistration.Password).ConfigureAwait(false);

            if (result.Succeeded)
            {
             var roleResult =  await _userManager.AddToRoleAsync(user,userRegistration.Role);
                
                if (roleResult.Succeeded)
                {
                    user = await _userManager.FindByNameAsync(userRegistration.UserName);
                    newUser.UserId = user.Id;
                    newUser.UserName = user.UserName;
                    newUser.UserRole = userRegistration.Role;
                  
                }

            }
          
            return newUser;

        }
        public async Task<bool> CreateRole(string roleName)
        {
            bool Created = false;
            if (roleName != null)
            {
                ApplicationRole newRole = new ApplicationRole();
                newRole.Name = roleName;
                await _roleManager.CreateAsync(newRole);
                Created = true;
            }
            return Created;
        }
        public async Task<List<string>> GetRoleList()
        {
            var RoleList = await _dBContext.tblSB_Roles.Select(a=>a.Name).ToListAsync();
            return RoleList;
        }

            public async Task<ApplicationUserDTO> DefaultUserRegisteration()
        {
            ApplicationUserDTO defaultUser = new ApplicationUserDTO();
            var IsExist = await _userManager.FindByNameAsync(_configuration["DefaultUser:UserName"]);
            if (IsExist ==null || IsExist.UserName ==null)
            {
                var user = new ApplicationUser
                {
                    UserName = _configuration["DefaultUser:UserName"],
                    Email = _configuration["DefaultUser:EmailId"],
                    CreatedBy = "SystemDefault",
                    ModifiedBy = "SystemDefault",
                    IsActive = true,
                    IsDeleted = false,
                    CreatedDate = DateTime.UtcNow,
                    ModifiedDate = DateTime.UtcNow,
                };

                var result = await _userManager.CreateAsync(user, _configuration["DefaultUser:Password"]).ConfigureAwait(false);

                if (result.Succeeded)
                {
                    var role = new ApplicationRole
                    {
                        Name = "SuperAdmin",
                    };

                    await _roleManager.CreateAsync(role);

                    var roleResult = await _userManager.AddToRoleAsync(user, "SuperAdmin");

                    if (roleResult.Succeeded)
                    {
                        user = await _userManager.FindByNameAsync(_configuration["DefaultUser:UserName"]);
                        defaultUser.UserId = user.Id;
                        defaultUser.UserName = user.UserName;
                        defaultUser.UserRole = "SuperAdmin";

                    }

                }

            }

            return defaultUser;

        }

        public async Task<LoginResponse> UserLogin(Login loginRequest)
        {
            LoginResponse loginResponse = new LoginResponse();
            var user = await _userManager.FindByNameAsync(loginRequest.UserName);
            if (user != null && user.IsActive && await _userManager.CheckPasswordAsync(user, loginRequest.Password).ConfigureAwait(false))
            {
                var userRoles = await _userManager.GetRolesAsync(user).ConfigureAwait(false);
                var authClaims = new List<Claim>
                {
                    new Claim(ClaimTypes.Name, user.UserName),
                    new Claim(ClaimTypes.Email,user.Email),
                    new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString()),
                };
                foreach (var userRole in userRoles)
                {
                    authClaims.Add(new Claim(ClaimTypes.Role, userRole));
                }

                var authSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_configuration["JsonWebTokenKeys:IssuerSigningKey"]));
                var token = new JwtSecurityToken(_configuration["JsonWebTokenKeys:ValidIssuer"], _configuration["JsonWebTokenKeys:ValidIssuer"],

                    expires: DateTime.UtcNow.AddHours(2),
                    claims: authClaims,
                    signingCredentials: new SigningCredentials(authSigningKey, SecurityAlgorithms.HmacSha256)
                    );
                loginResponse.Token = new JwtSecurityTokenHandler().WriteToken(token);
                loginResponse.UserName = user.UserName;
                loginResponse.UserRole = userRoles.ToArray();
            }
            return loginResponse;
        }
    }
}
