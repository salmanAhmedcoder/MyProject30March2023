﻿using System;

namespace SB_ServiceLayer
{
    public class Class1
    {
    }
}
