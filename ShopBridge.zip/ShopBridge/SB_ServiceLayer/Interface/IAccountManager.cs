﻿using SB_DomainLayer.DTO;
using SB_DomainLayer.RequestModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SB_ServiceLayer.Interface
{
   public interface IAccountManager
    {
        Task<bool> CreateRole(string roleName);
        Task<ApplicationUserDTO> UserRegisteration(UserRegistration userRegistration, string createdBy);
        Task<ApplicationUserDTO> DefaultUserRegisteration();
        Task<List<string>> GetRoleList();
        Task<LoginResponse> UserLogin(Login loginRequest);
    }
}
