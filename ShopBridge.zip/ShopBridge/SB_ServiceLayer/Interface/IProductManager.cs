﻿using SB_DomainLayer.Models;
using SB_DomainLayer.RequestModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SB_ServiceLayer.Interface
{
    public interface IProductManager
    {
        Task<List<ProductListingDetail>> GetAllListedProductByProductId(int productId);
        Task<List<ProductDetail>> GetProductListForCategory(string category);
        Task<List<ProductDetail>> GetAllProductList();
        Task<bool> DeleteProductByProductId(int productId, string updatedBy);
        Task<bool> ListProductForSale(ListProduct product, string addedBy);
        Task<bool> UpdatePriceOfListedProduct(ListProduct product);
        Task<bool> UpdateQuantityOfListedProduct(ListProduct product);
        Task<bool> BuyListedProduct(BuyProduct product, string purchasedBy);
        Task<bool> AddProductWithDetails(AddProduct product, string addedBy);
        Task<bool> UpdateProductDetails(ProductDetail product, string updatedBy);

    }
}
