﻿using Microsoft.AspNetCore.Mvc.Filters;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Shopbridge.Logger
{
    public  class LogAttribute : ActionFilterAttribute
    {

        public override void OnActionExecuted(ActionExecutedContext filterContext)
        {
            if (filterContext.Result != null)
            {
                var type = filterContext.Result.GetType().Name;
                StringBuilder result = new StringBuilder();
                result.Append("Result - ");
                if (type != "RedirectToActionResult")
                {
                    result.Append(JsonConvert.SerializeObject(filterContext.Result).ToString());
                    LogHandler.WriteTrace(filterContext.RouteData.Values, result, "OnResultExecuted");
                }
            }
         
        }

        public override void OnActionExecuting(ActionExecutingContext filterContext)
        {
            StringBuilder parameterList = new StringBuilder();
            parameterList.Append("Parameters List - ");
            parameterList.Append(JsonConvert.SerializeObject(filterContext.ActionArguments).ToString());
            LogHandler.WriteTrace(filterContext.RouteData.Values, parameterList, "OnActionExecuting");

        }



    }
}
