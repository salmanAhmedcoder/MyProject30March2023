﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace Shopbridge.Logger
{
    public class ExceptionModel
    {
        public ExceptionModel(string message
            , string? data, string? innerException, string? stackTrace)
        {
            Message = message;
            Data = data;
            InnerException = innerException;
            StackTrace = stackTrace;
        }

        public string Message { get; set; }
        public string? Data { get; set; }
        public string? InnerException { get; set; }
        public string? StackTrace { get; set; }
    }

    public class ErrorDetails
    {
        public int StatusCode { get; set; }
        public string Message { get; set; }
       public bool Success { get; set; }
    }
}
