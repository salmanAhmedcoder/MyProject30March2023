﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using SB_DomainLayer.DTO;
using SB_DomainLayer.Models;
using SB_DomainLayer.RequestModel;
using SB_ServiceLayer.Interface;
using Shopbridge.Logger;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Security.Claims;
using System.Threading.Tasks;

namespace Shopbridge.Controllers
{
    [Log]
    [ApiController]
    [Route("api/[controller]/[action]")]
    public class AccountController : ControllerBase
    {
        private readonly IAccountManager _accountManager;
        private readonly SignInManager<ApplicationUser> _signInManager;
        private readonly RoleManager<ApplicationRole> _roleManager;
        private readonly UserManager<ApplicationUser> _userManager;
        public ResponseDTO response = new ResponseDTO();
        public AccountController(IAccountManager accountManager, RoleManager<ApplicationRole> roleManager, UserManager<ApplicationUser> userManager, SignInManager<ApplicationUser> signInManager

            )
        
        {
            _roleManager = roleManager;
            _userManager = userManager;
            _accountManager = accountManager;
            _signInManager = signInManager;

        }

      
        [HttpPost]
        [AllowAnonymous]
        public async Task<IActionResult> UserRegisteration(UserRegistration userRegistration)
        {
            if (ModelState.IsValid && User.Identity.IsAuthenticated)
            {
                var result = await _accountManager.UserRegisteration(userRegistration, User.Identity.Name).ConfigureAwait(false);

                if (result != null)
                {
                    response.Data = result;
                    response.StatusCode = (int)HttpStatusCode.OK;
                    return Ok(response);
                }
            }

            return BadRequest();
        }

        [HttpPost]
        [Authorize(Roles = "SuperAdmin")]
        public async Task<IActionResult> CreateRole(string newRole)
        {
            if (ModelState.IsValid && User.Identity.IsAuthenticated)
            {
                var result = await _accountManager.CreateRole(newRole);

                if (result)
                {
                    response.Data = newRole;
                    response.StatusCode = (int)HttpStatusCode.OK;
                    return Ok(response);
                }
            }

            return BadRequest();
        }

        [HttpPost]
        [AllowAnonymous]
        public async Task<IActionResult> FirstUserRegisteration()
        {

                var result = await _accountManager.DefaultUserRegisteration().ConfigureAwait(false);

                if (result != null)
                {
                    response.Data = result;
                    response.StatusCode = (int)HttpStatusCode.OK;
                    return Ok(response);
                }
            

            return BadRequest();
        }

        [HttpGet]
        [Authorize(Roles = "SuperAdmin")]
        public async Task<IActionResult> GetRoleList()
        {

            var result = await _accountManager.GetRoleList().ConfigureAwait(false);
            if (result != null)
            {
                response.Data = result;
                response.StatusCode = (int)HttpStatusCode.OK;
                return Ok(response);
            }
            return BadRequest();
        }


        [HttpPost]
        [Authorize]
        public async Task<IActionResult> Logout()
        {
            await _signInManager.SignOutAsync();
            response.Message = "Logout Successfull";
            response.StatusCode = (int)HttpStatusCode.OK;
            return Ok(response);
        }

        [HttpPost]
        [AllowAnonymous]
        public async Task<IActionResult>UserLogin(Login loginRequest)
        {
            
            if(loginRequest.UserName!=null && loginRequest.Password != null)
            {
                response.Data = await _accountManager.UserLogin(loginRequest);
                response.StatusCode = (int)HttpStatusCode.OK;
                return Ok(response);
            }
                return BadRequest();
        }

        [HttpGet]
        [Authorize(Roles = "SuperAdmin")]
        public IActionResult Test()
        {

                response.Data = "Hello Test";
                response.StatusCode = (int)HttpStatusCode.OK;
                return Ok(response);
        }


    }
}
