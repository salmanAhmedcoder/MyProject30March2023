﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using SB_DomainLayer.DTO;
using SB_DomainLayer.Models;
using SB_DomainLayer.RequestModel;
using SB_ServiceLayer.Interface;
using Shopbridge.Logger;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;

namespace Shopbridge.Controllers
{
    [Log]
    [ApiController]
    [Authorize]
    [Route("api/[controller]/[action]")]
    public class ProductController : ControllerBase
    {
        private readonly IAccountManager _accountManager;
        private readonly IProductManager _productManager;
        private readonly SignInManager<ApplicationUser> _signInManager;
        private readonly RoleManager<ApplicationRole> _roleManager;
        private readonly UserManager<ApplicationUser> _userManager;
        public ResponseDTO response = new ResponseDTO();
        public ProductController(IAccountManager accountManager, IProductManager productManager,RoleManager<ApplicationRole> roleManager, UserManager<ApplicationUser> userManager, SignInManager<ApplicationUser> signInManager

            )

        {
            _roleManager = roleManager;
            _productManager = productManager;
            _userManager = userManager;
            _accountManager = accountManager;
            _signInManager = signInManager;

        }
        /// <summary>
        /// API to get the list of all the products.
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [AllowAnonymous]
        public async Task<IActionResult> GetProductList()
        {

         
                var result = await _productManager.GetAllProductList();
                if (result !=null)
                {
                  
                    response.Data = result;
                    response.StatusCode = (int)HttpStatusCode.OK;
                    return Ok(response);
                }
            return BadRequest();
        }

        /// <summary>
        /// API for any user to get list of products in any one category.
        /// </summary>
        /// <param name="Category"></param>
        /// <returns></returns>
        [HttpGet]
        [AllowAnonymous]
        public async Task<IActionResult> GetProductListByCategory(string Category)
        {


            var result = await _productManager.GetProductListForCategory(Category);
            if (result != null)
            {

                response.Data = result;
                response.StatusCode = (int)HttpStatusCode.OK;
                return Ok(response);
            }
            return BadRequest();
        }

        /// <summary>
        /// API for any one to see how many products are there and what prices so that user can compare and choose between sellers and decide from which seller to buy.
        /// </summary>
        /// <param name="ProductId"></param>
        /// <returns></returns>
        [HttpGet]
        [AllowAnonymous]
        public async Task<IActionResult> GetListedProductsForProductId(int ProductId)
        {


            var result = await _productManager.GetAllListedProductByProductId(ProductId);
            if (result != null)
            {

                response.Data = result;
                response.StatusCode = (int)HttpStatusCode.OK;
                return Ok(response);
            }
            return BadRequest();
        }
        /// <summary>
        /// API for admin to add a new product.
        /// </summary>
        /// <param name="product"></param>
        /// <returns></returns>
        [HttpPost]
        [Authorize(Roles ="Admin")]
        public async Task<IActionResult> AddProduct(AddProduct product)
        {

            if (product!=null && product.ProductDescription!=null)
            {
                var result = await _productManager.AddProductWithDetails(product, User.Identity.Name);
                if (result)
                {
                    response.Message = "Product added succcessfully";
                    response.Data = true;
                    response.StatusCode = (int)HttpStatusCode.OK;
                    return Ok(response);
                }
              
            }
            return BadRequest();
        }

        /// <summary>
        /// API to delete a product
        /// </summary>
        /// <param name="product"></param>
        /// <returns></returns>
        [HttpPost]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> DeleteProduct(int productId)
        {

            if (productId>0)
            {
                var result = await _productManager.DeleteProductByProductId(productId, User.Identity.Name);
                if (result)
                {
                    response.Message = "Product added succcessfully";
                    response.Data = true;
                    response.StatusCode = (int)HttpStatusCode.OK;
                    return Ok(response);
                }

            }
            return BadRequest();
        }
        /// <summary>
        /// API for admin to update a product's detail.
        /// </summary>
        /// <param name="product"></param>
        /// <returns></returns>
        [HttpPost]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> UpdateProductDetail(ProductDetail product)
        {

            if (product != null && product.ProductID>0 && product.ProductDescription != null)
            {
                var result = await _productManager.UpdateProductDetails(product, User.Identity.Name);
                if (result)
                {
                    response.Message = "Product added succcessfully";
                    response.Data = true;
                    response.StatusCode = (int)HttpStatusCode.OK;
                    return Ok(response);
                }

            }
            return BadRequest();
        }

        /// <summary>
        /// API for seller to list his product for sale from already added product list.
        /// </summary>
        /// <param name="product"></param>
        /// <returns></returns>
        [HttpPost]
        [Authorize(Roles = "Seller")]
        public async Task<IActionResult> ListProductForSale(ListProduct product)
        {

            if (product != null && product.ProductId > 0)
            {
                response.Data = await _productManager.ListProductForSale(product, User.Identity.Name);
                response.StatusCode = (int)HttpStatusCode.OK;
                return Ok(response);
            }
            return BadRequest();
        }
        /// <summary>
        /// API for seller to update the price of his listed products.
        /// </summary>
        /// <param name="product"></param>
        /// <returns></returns>
        [HttpPost]
        [Authorize(Roles = "Seller")]
        public async Task<IActionResult> UpdatePriceOfListedProduct(ListProduct product)
        {

            if (product != null && product.ProductId > 0)
            {
                response.Data = await _productManager.UpdatePriceOfListedProduct(product);
                response.StatusCode = (int)HttpStatusCode.OK;
                return Ok(response);
            }
            return BadRequest();
        }

        /// <summary>
        /// API for seller to add or remove some of his listed products
        /// </summary>
        /// <param name="product"></param>
        /// <returns></returns>
        [HttpPost]
        [Authorize(Roles = "Seller")]
        public async Task<IActionResult> UpdateQuantityOfListedProduct(ListProduct product)
        {

            if (product != null && product.ProductId > 0)
            {
                response.Data = await _productManager.UpdateQuantityOfListedProduct(product);
                response.StatusCode = (int)HttpStatusCode.OK;
                return Ok(response);
            }
            return BadRequest();
        }
        /// <summary>
        /// API for buyer to buy a product.
        /// </summary>
        /// <param name="product"></param>
        /// <returns></returns>
        [HttpPost]
        [Authorize(Roles = "Buyer")]
        public async Task<IActionResult> BuyProduct(BuyProduct product)
        {

            if (product != null && product.Quantity > 0)
            {
                response.Data = await _productManager.BuyListedProduct(product,User.Identity.Name);
                response.StatusCode = (int)HttpStatusCode.OK;
                return Ok(response);
            }
            return BadRequest();
        }
       
    }
}
