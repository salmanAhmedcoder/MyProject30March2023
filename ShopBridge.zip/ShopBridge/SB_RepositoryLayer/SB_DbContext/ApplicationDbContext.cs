﻿using Microsoft.EntityFrameworkCore;
using SB_DomainLayer.Models;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;

namespace SB_RepositoryLayer.SB_DbContext
{

    public class ApplicationDbContext : IdentityDbContext<ApplicationUser, ApplicationRole,string, ApplicationUserClaim, ApplicationUserRole, ApplicationUserLogin, ApplicationRoleClaim, ApplicationUserToken>        
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {

        }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<ApplicationUser>()
               .ToTable("tblSB_Users");

            modelBuilder.Entity<ApplicationRole>()
                    .ToTable("tblSB_Roles");

            modelBuilder.Entity<ApplicationUserRole>()
                    .ToTable("tblSB_UserRoles");

            modelBuilder.Entity<ApplicationRoleClaim>()
                    .ToTable("tblSB_RoleClaims");

            modelBuilder.Entity<ApplicationUserClaim>()
                  .ToTable("tblSB_UserClaims");
           
            modelBuilder.Entity<ApplicationUserToken>()
                 .ToTable("tblSB_UserToken");

            modelBuilder.Entity<ApplicationUserLogin>()
                  .ToTable("tblSB_UserLogin");

        }
        public DbSet<ApplicationUser> tblSB_Users { get; set; }
        public DbSet<ApplicationRole> tblSB_Roles { get; set; }
        public DbSet<ApplicationUserRole> tblSB_UserRoles { get; set; }
        public DbSet<ApplicationUserClaim> tblSB_UserClaims { get; set; }
        public DbSet<ApplicationRoleClaim> tblSB_RoleClaims { get; set; }
        public DbSet<ApplicationUserLogin> tblSB_UserLogin { get; set; }
        public DbSet<ApplicationUserToken> tblSB_UserToken { get; set; }
        public DbSet<ProductDetail> tblSB_ProductDetail { get; set; }
        public DbSet<ProductListingDetail> tblSB_ProductListingDetail { get; set; }
        public DbSet<ProductSellingDetail> tblSB_ProductSellingDetail { get; set; }

    } 
}
