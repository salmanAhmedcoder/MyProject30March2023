﻿using System;

namespace SB_RepositoryLayer
{
    public class Class1
    {
    }
}
