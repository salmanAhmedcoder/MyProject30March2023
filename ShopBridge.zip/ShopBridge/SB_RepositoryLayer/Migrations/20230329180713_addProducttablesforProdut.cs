﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace SB_RepositoryLayer.Migrations
{
    public partial class addProducttablesforProdut : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "ProductID",
                table: "tblSB_ProductSellingDetail",
                newName: "ListedId");

            migrationBuilder.RenameColumn(
                name: "SellingPrice",
                table: "tblSB_ProductListingDetail",
                newName: "UnitSellingPrice");

            migrationBuilder.AddColumn<DateTime>(
                name: "LastModifiedDateTime",
                table: "tblSB_ProductListingDetail",
                type: "datetime2",
                nullable: false,
                defaultValue: new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.AddColumn<int>(
                name: "Quantity",
                table: "tblSB_ProductListingDetail",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<string>(
                name: "CreatedBy",
                table: "tblSB_ProductDetail",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<DateTime>(
                name: "CreatedDateTime",
                table: "tblSB_ProductDetail",
                type: "datetime2",
                nullable: false,
                defaultValue: new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.AddColumn<string>(
                name: "ModifiedBy",
                table: "tblSB_ProductDetail",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<DateTime>(
                name: "ModifiedDateTime",
                table: "tblSB_ProductDetail",
                type: "datetime2",
                nullable: false,
                defaultValue: new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "LastModifiedDateTime",
                table: "tblSB_ProductListingDetail");

            migrationBuilder.DropColumn(
                name: "Quantity",
                table: "tblSB_ProductListingDetail");

            migrationBuilder.DropColumn(
                name: "CreatedBy",
                table: "tblSB_ProductDetail");

            migrationBuilder.DropColumn(
                name: "CreatedDateTime",
                table: "tblSB_ProductDetail");

            migrationBuilder.DropColumn(
                name: "ModifiedBy",
                table: "tblSB_ProductDetail");

            migrationBuilder.DropColumn(
                name: "ModifiedDateTime",
                table: "tblSB_ProductDetail");

            migrationBuilder.RenameColumn(
                name: "ListedId",
                table: "tblSB_ProductSellingDetail",
                newName: "ProductID");

            migrationBuilder.RenameColumn(
                name: "UnitSellingPrice",
                table: "tblSB_ProductListingDetail",
                newName: "SellingPrice");
        }
    }
}
