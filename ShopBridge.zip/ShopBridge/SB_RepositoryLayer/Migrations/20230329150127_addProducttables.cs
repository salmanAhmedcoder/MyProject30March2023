﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace SB_RepositoryLayer.Migrations
{
    public partial class addProducttables : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "IsAvailable",
                table: "tblSB_ProductDetail");

            migrationBuilder.DropColumn(
                name: "ProductPrice",
                table: "tblSB_ProductDetail");

            migrationBuilder.AlterColumn<string>(
                name: "ProductCategory",
                table: "tblSB_ProductDetail",
                type: "nvarchar(max)",
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int");

            migrationBuilder.AddColumn<string>(
                name: "ProductDescription",
                table: "tblSB_ProductDetail",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.CreateTable(
                name: "tblSB_ProductListingDetail",
                columns: table => new
                {
                    ID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ProductID = table.Column<int>(type: "int", nullable: false),
                    SellerID = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    SellingPrice = table.Column<decimal>(type: "decimal(18,2)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_tblSB_ProductListingDetail", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "tblSB_ProductSellingDetail",
                columns: table => new
                {
                    ID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ProductID = table.Column<int>(type: "int", nullable: false),
                    PurchasedBy = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    PurchasePrice = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    Quantity = table.Column<int>(type: "int", nullable: false),
                    PurchasedDateTime = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_tblSB_ProductSellingDetail", x => x.ID);
                });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "tblSB_ProductListingDetail");

            migrationBuilder.DropTable(
                name: "tblSB_ProductSellingDetail");

            migrationBuilder.DropColumn(
                name: "ProductDescription",
                table: "tblSB_ProductDetail");

            migrationBuilder.AlterColumn<int>(
                name: "ProductCategory",
                table: "tblSB_ProductDetail",
                type: "int",
                nullable: false,
                defaultValue: 0,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)",
                oldNullable: true);

            migrationBuilder.AddColumn<bool>(
                name: "IsAvailable",
                table: "tblSB_ProductDetail",
                type: "bit",
                nullable: false,
                defaultValue: false);

            migrationBuilder.AddColumn<int>(
                name: "ProductPrice",
                table: "tblSB_ProductDetail",
                type: "int",
                nullable: false,
                defaultValue: 0);
        }
    }
}
