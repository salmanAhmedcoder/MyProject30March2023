﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SB_DomainLayer.RequestModel
{
   public class ListProduct
    {
        public int ListedID { get; set; }
        public int ProductId { get; set; }
        public int? Quantity { get; set; }
        public decimal? UnitSellingPrice { get; set; }
    }
}
