﻿using System;
using Microsoft.AspNetCore.Identity;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SB_DomainLayer.Models
{
     public  class ApplicationUser:IdentityUser
    {
        public bool IsDeleted { get; set; }
        public bool IsActive { get; set; }
        public DateTime CreatedDate { get; set; }
        public string CreatedBy { get; set; }
        public DateTime ModifiedDate { get; set; }
        public string ModifiedBy { get; set; }

    }
    public class ApplicationRole : IdentityRole
    {


    }
    public class ApplicationUserRole : IdentityUserRole<string>
    {


    }
    public class ApplicationUserClaim : IdentityUserClaim<string>

    {


    }
    public class ApplicationRoleClaim : IdentityRoleClaim<string>

    {


    }
    public class ApplicationUserLogin : IdentityUserLogin<string>

    {


    }
    public class ApplicationUserToken : IdentityUserToken<string>

    {


    }

}
