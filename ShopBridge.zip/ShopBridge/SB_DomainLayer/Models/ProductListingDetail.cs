﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SB_DomainLayer.Models
{
    public class ProductListingDetail
    {
        [Key]
        [Required]
        public int ID { get; set; }
        public int ProductID { get; set; }
        public string SellerID { get; set; }
        public int Quantity { get; set; }
        public decimal UnitSellingPrice { get; set; }
        public DateTime LastModifiedDateTime { get; set; }

    }
}
