﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SB_DomainLayer.Models
{
   public class ProductSellingDetail
    {
        [Required]
        [Key]
        public int ID { get; set; }
        public int ListedId { get; set; }
        public string PurchasedBy { get; set; }
        public decimal PurchasePrice { get; set; }
        public int Quantity { get; set; }
        public DateTime PurchasedDateTime { get; set; }
    }
}
