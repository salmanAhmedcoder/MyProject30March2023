﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SB_DomainLayer.DTO
{
    public class ResponseDTO
    {
        public ResponseDTO()
        {
            Error = false;
        }
        public string Message { get; set; }

        public int StatusCode { get; set; }
        public bool Error { get; set; }

        public object Data { get; set; }


    }
}
